FIRST to create the database go to the the CREATION folder.
In the folder you should find CREATETABLEQUERY.sql
This file is also our DDL file.
Running this in MySQL Workbench will create the schema and all the tables.

After this run product.sql to fill products after selecting videogamestore as your main schema
then EXAMPLE.sql file 
this will fill in data into the database

IF you want to create random data there is a python script that will create a file 'RunToInsert.sql'
This will generate a sql file to run to input data. product.sql is the only thing that stays consistent.

After this the database is created

The '7SQLQueriesTask4' folder has the 7 queries requested in task 4
The queries are assigned by number given in task 4.

Images of each query running are in the same folder as each query.

the text of each query is in the .sql files explained previously

The Description PDF Answers question #6 on the task_4 list. 