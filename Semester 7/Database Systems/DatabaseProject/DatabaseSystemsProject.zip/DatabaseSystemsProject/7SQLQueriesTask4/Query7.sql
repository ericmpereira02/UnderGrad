SELECT Product_Id, Price FROM videogamestore.product
WHERE Price BETWEEN 150 AND 250
