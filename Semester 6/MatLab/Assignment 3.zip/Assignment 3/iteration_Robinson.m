function equation = iteration_Robinson(a)

a = sqrt(7/2*cos(a));
disp(a);

end

